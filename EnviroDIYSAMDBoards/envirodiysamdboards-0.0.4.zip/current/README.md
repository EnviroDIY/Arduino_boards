# Arduino board support package

This package contains Arduino board support files for EnviroDIY Stonefly by EnviroDIY (https://www.envirodiy.org/).
This package is version 0.0.4, built on 2025-01-08.

It relies on Adafruit's SAMD board support package; thus, users need to have that package installed. 
Please see installation instructions here: https://learn.adafruit.com/add-boards-arduino-v164/setup

This package was built using tools from https://github.com/shurik179/SAMD-custom-board repository. 

