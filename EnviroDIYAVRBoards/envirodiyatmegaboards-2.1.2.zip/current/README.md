# Arduino board support package

This package contains Arduino board support files for AVR boards developed by EnviroDIY (https://www.envirodiy.org/).
This package is version 2.1.2, built on 2026-06-18.

This package was built using tools from https://github.com/shurik179/SAMD-custom-board repository.
